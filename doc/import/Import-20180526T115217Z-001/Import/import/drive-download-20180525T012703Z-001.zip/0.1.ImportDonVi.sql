-- 1. Import đơn vị
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'AG','TRUNG TÂM Y TẾ DỰ PHÒNG AN GIANG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (2,'BT','BỆNH VIỆN LAO VÀ BỆNH PHỔI BẾN TRE',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (3,'BL','TRUNG TÂM PHÒNG CHỐNG BỆNH XÃ HỘI BẠC LIÊU',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (4,'CM','TRUNG TÂM PHÒNG CHỐNG BỆNH XÃ HỘI CÀ MAU',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (5,'CT','BỆNH VIÊN LAO VÀ BỆNH PHỔI TP.CẦN THƠ',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (6,'HG','BỆNH VIỆN LAO & BỆNH PHỔI HẬU GIANG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (7,'ST','BỆNH VIỆN 30 THÁNG 4 SÓC TRĂNG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (8,'TV','BỆNH VIỆN LAO & BỆNH PHỔI TRÀ VINH',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (9,'VL','BỆNH VIỆN LAO & BỆNH PHỔI VĨNH LONG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (10,'DT','BỆNH VIỆN LAO VÀ BỆNH PHỔI ĐỒNG THÁP',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (11,'TG','BỆNH VIỆN LAO VÀ BỆNH PHỔI TIỀN GIANG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (12,'LA','BỆNH VIỆN LAO VÀ BỆNH PHỔI LONG AN',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (13,'KG','TRUNG TÂM PHÒNG CHỐNG BỆNH XÃ HỘI KIÊN GIANG',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (14,'TN','BỆNH VIỆN LAO & BỆNH PHỔI TÂY NINH',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (15,'HCM','BỆNH VIỆN PHẠM NGỌC THẠCH - TP HỒ CHÍ MINH',NULL,NULL,NULL);
INSERT INTO `u883604362_store`.`store_donvi` (`id`, `ma_donvi`, `ten_donvi`, `deleted_at`, `created_at`, `updated_at`) VALUES (16,'VN','CTY TNHH GIÁM ĐỊNH VINACONTROL TP.HCM-CN CẦN THƠ',NULL,NULL,NULL);
